<?php

//pathes
$_TPLPATH  = 'templates/';
$_PAGETPLPATH = '';
$_BASEPATH = __DIR__."/..";

$_VARS = [];
$_ext = 'html';
$_VARS['index']=[
    'type'=>'',
    'file'=>[
        'name'=>'index',
        'ext'=>$_ext,
        'skip'=>1,
    ],
    [

    ]
];




