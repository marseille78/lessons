<?php
/**
 * @rendered at:
 * @param string 'page-content'
 */
?>
<!-- page-about START -->
<article>
    <?=variable($var, 'page-content'); ?>
</article>
<!-- page-about END -->
