<div class="form-sexy_select">
	<div class="result_sexy_select">hhh</div>
	<form action="">
		<select name="" id="<?=variable($var, 'id')?>">
			<?=render('form_sexy_select_item', variable($var, 'data_form_sexy_select_item'))?>
		</select>
	</form>
</div>