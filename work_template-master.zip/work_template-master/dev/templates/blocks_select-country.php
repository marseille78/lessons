<?php
/**
 * @rendered at: page-example.php
 * @param array $var['select_countries']
 */
?>
<!-- blocks_select-country START -->
<div class="select-country">
	<?=render('form_sexy_select', variable($var, 'data_form_sexy_select')); ?>
</div>
<!-- blocks_select-country END -->