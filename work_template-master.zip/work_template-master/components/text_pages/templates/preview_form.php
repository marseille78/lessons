<form action="">
    <fieldset>
        <legend>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Maiores, quasi!</legend>

        <label for="">
            <input type="text" placeholder="placeholder">
        </label> <br>

        <label for="">Lorem ipsum dolor sit amet.</label> <br>

        <select name="" id="">
            <option value="">Lorem ipsum dolor.</option>
            <option value="">Animi, fugiat, saepe?</option>
            <option value="">Deserunt, doloribus nesciunt!</option>
            <option value="">Iure laborum, nesciunt!</option>
            <option value="">Dolore quaerat, rerum.</option>
        </select> <br>

        <input type="checkbox"> Lorem ipsum dolor sit amet. <br>
        <input type="radio"> Lorem ipsum dolor sit amet. <br>

        <input type="email"> <br>
        <input type="number"> <br>
        <input type="tel"> <br>
        <input type="search"> <br>
        <input type="password"> <br>

        <input type="time"> <br>
        <input type="date"> <br>
        <input type="datetime"> <br>
        <input type="datetime-local"> <br>

        <input type="range"> <br>
        <input type="color"> <br>

        <input type="button" value="button"> <br>
        <input type="reset" value="reset"> <br>
        <input type="submit" value="submit"> <br>
        <button>button</button> <br>

        <textarea name="" id="" cols="30" rows="10">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Debitis ipsa libero, praesentium quos saepe voluptate!</textarea>
        <br>
    </fieldset>
</form>